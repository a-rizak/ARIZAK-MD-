// server.js
const express = require('express');
const fs = require('fs');
const path = require('path');
const qrcode = require('qrcode');
const P = require('pino');
const { makeWASocket, useSingleFileAuthState } = require('@whiskeysockets/baileys');

const logger = P({ level: 'info' });
const app = express();
app.use(express.json());

const SESSIONS_DIR = path.join(__dirname, 'sessions');
if (!fs.existsSync(SESSIONS_DIR)) fs.mkdirSync(SESSIONS_DIR);

const sessions = {};

async function createOrGetSession(credId) {
  const safeId = credId.replace(/[^a-zA-Z0-9_-]/g, '_');
  const authFile = path.join(SESSIONS_DIR, `${safeId}.json`);
  const { state, saveState } = useSingleFileAuthState(authFile);

  if (sessions[safeId] && sessions[safeId].socket) {
    const s = sessions[safeId];
    return { status: s.status || 'connected' };
  }

  const sock = makeWASocket({
    logger,
    printQRInTerminal: false,
    auth: state
  });

  sessions[safeId] = { socket: sock, status: 'connecting' };

  sock.ev.on('creds.update', saveState);
  sock.ev.on('connection.update', async (update) => {
    const { connection, qr } = update;

    if (qr) {
      const dataUrl = await qrcode.toDataURL(qr);
      sessions[safeId].qr = dataUrl;
      sessions[safeId].status = 'qr';
    }

    if (connection === 'open') {
      sessions[safeId].status = 'connected';
      delete sessions[safeId].qr;
    }

    if (connection === 'close') {
      sessions[safeId].status = 'disconnected';
    }
  });

  return { status: sessions[safeId].status, qr: sessions[safeId].qr };
}

app.get('/code', async (req, res) => {
  try {
    const number = String(req.query.number || '');
    if (!number) return res.status(400).json({ error: 'missing number' });
    const digits = number.replace(/\D/g, '');
    if (digits.length < 8) return res.status(400).json({ error: 'invalid number' });
    const result = await createOrGetSession(digits);
    if (result.qr) return res.json({ code: 'QR_AVAILABLE', qr: result.qr });
    else return res.json({ code: 'NO_QR', status: result.status });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'server error' });
  }
});

app.get('/status', (req, res) => {
  const number = String(req.query.number || '');
  const safeId = number.replace(/[^a-zA-Z0-9_-]/g, '_');
  const s = sessions[safeId];
  if (!s) return res.json({ status: 'no_session' });
  res.json({ status: s.status });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => logger.info(`ARIZAK-MD server running on http://localhost:${PORT}`));
